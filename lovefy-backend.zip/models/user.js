const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./db.sqlite');

module.exports = {
  getUserByEmail: (email) => {
    return new Promise((resolve, reject) => {
      db.get('SELECT * FROM users WHERE email = ?', [email], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });
  },

  createUser: (name, email, password, ref) => {
    return new Promise((resolve, reject) => {
      const codigoIndicacao = generateReferralCode(name);
      db.run('INSERT INTO users (name, email, password, codigo_indicacao, indicado_por) VALUES (?, ?, ?, ?, ?)', [name, email, password, codigoIndicacao, ref || null], function(err) {
        if (err) reject(err);
        else resolve({ lastID: this.lastID });
      });
    });
  },

  getUserById: (id) => {
    return new Promise((resolve, reject) => {
      db.get('SELECT * FROM users WHERE id = ?', [id], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });
  },

  getUsersByReferral: (refCode) => {
    return new Promise((resolve, reject) => {
      db.all('SELECT id, name, email FROM users WHERE indicado_por = ?', [refCode], (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });
  },

  createCouple: (userId, coupleName, eventDate, phrase, color, extra) => {
    return new Promise((resolve, reject) => {
      db.run('INSERT INTO couples (user_id, couple_name, event_date, phrase, color, extra) VALUES (?, ?, ?, ?, ?, ?)', [userId, coupleName, eventDate, phrase, color, extra], function(err) {
        if (err) reject(err);
        else resolve({ lastID: this.lastID });
      });
    });
  },

  getAllUsers: () => {
    return new Promise((resolve, reject) => {
      db.all('SELECT id, name, email, codigo_indicacao, indicado_por FROM users', [], (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });
  },

  getAllCouples: () => {
    return new Promise((resolve, reject) => {
      db.all('SELECT * FROM couples', [], (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });
  }
};

function generateReferralCode(name) {
  return name.toLowerCase().replace(/\s+/g, '') + Math.floor(Math.random() * 10000);
}